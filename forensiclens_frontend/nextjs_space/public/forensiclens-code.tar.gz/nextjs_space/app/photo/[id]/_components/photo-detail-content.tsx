"use client";
import { useEffect, useState, useRef, useCallback } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import {
  Scan, ZoomIn, Download, ArrowLeft, Loader2, CheckCircle2, AlertCircle,
  ImageIcon, SplitSquareHorizontal, Eye, Maximize2, MinusCircle, PlusCircle,
  RefreshCw, Clock, FileType, HardDrive
} from "lucide-react";
import type { PhotoRecord } from "@/lib/types";
import toast from "react-hot-toast";

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };

interface Props {
  photoId: string;
}

export default function PhotoDetailContent({ photoId }: Props) {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [photo, setPhoto] = useState<PhotoRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [anomalyProcessing, setAnomalyProcessing] = useState(false);
  const [upscaleProcessing, setUpscaleProcessing] = useState(false);
  const [activeView, setActiveView] = useState<"original" | "anomaly" | "upscaled" | "compare">("original");
  const [zoom, setZoom] = useState(1);
  const [comparePosition, setComparePosition] = useState(50);
  const compareRef = useRef<HTMLDivElement>(null);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (status === "unauthenticated") router.replace("/login");
  }, [status, router]);

  const fetchPhoto = useCallback(async () => {
    try {
      const res = await fetch(`/api/photos/${photoId}`);
      if (res?.ok) {
        const data = await res.json();
        setPhoto(data);
        return data;
      }
    } catch (err: any) { console.error(err); }
    return null;
  }, [photoId]);

  useEffect(() => {
    if (status !== "authenticated" || !photoId) return;
    const load = async () => {
      await fetchPhoto();
      setLoading(false);
    };
    load();
  }, [status, photoId, fetchPhoto]);

  // Polling for processing status
  useEffect(() => {
    if (!anomalyProcessing && !upscaleProcessing) {
      if (pollingRef.current) { clearInterval(pollingRef.current); pollingRef.current = null; }
      return;
    }
    pollingRef.current = setInterval(async () => {
      const data = await fetchPhoto();
      if (data?.anomalyStatus === "COMPLETED" || data?.anomalyStatus === "FAILED") setAnomalyProcessing(false);
      if (data?.upscaleStatus === "COMPLETED" || data?.upscaleStatus === "FAILED") setUpscaleProcessing(false);
    }, 3000);
    return () => { if (pollingRef.current) clearInterval(pollingRef.current); };
  }, [anomalyProcessing, upscaleProcessing, fetchPhoto]);

  const handleDetectAnomalies = async () => {
    if (!photo?.id) return;
    setAnomalyProcessing(true);
    try {
      const analyzeRes = await fetch(`/api/photos/${photo.id}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!analyzeRes.ok) {
        const errData = await analyzeRes.json().catch(() => ({}));
        throw new Error(errData?.error ?? `Analysis failed with status ${analyzeRes.status}`);
      }

      await fetchPhoto();
      setAnomalyProcessing(false);
      toast.success("Forensic analysis complete!");
    } catch (err: any) {
      console.error("Anomaly detection error:", err);
      setAnomalyProcessing(false);
      toast.error(err?.message ?? "Anomaly detection failed");
    }
  };

  const handleUpscale = async () => {
    if (!photo?.id) return;
    setUpscaleProcessing(true);
    try {
      const upscaleRes = await fetch(`/api/photos/${photo.id}/upscale`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!upscaleRes.ok) {
        const errData = await upscaleRes.json().catch(() => ({}));
        throw new Error(errData?.error ?? `Upscaling failed with status ${upscaleRes.status}`);
      }

      await fetchPhoto();
      setUpscaleProcessing(false);
      toast.success("Image upscaling complete!");
    } catch (err: any) {
      console.error("Upscale error:", err);
      setUpscaleProcessing(false);
      toast.error(err?.message ?? "Upscaling failed");
    }
  };

  const handleDownload = async (url: string | null | undefined, filename: string) => {
    if (!url) return;
    try {
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.target = "_blank";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch { toast.error("Download failed"); }
  };

  const handleCompareMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!compareRef?.current) return;
    const rect = compareRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
    setComparePosition(x);
  };

  if (status === "loading" || status === "unauthenticated" || loading) {
    return <div className="min-h-screen bg-[#0a0a1a] flex items-center justify-center"><div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" /></div>;
  }

  if (!photo) {
    return (
      <div className="min-h-screen bg-[#0a0a1a] grid-bg">
        <Navbar />
        <main className="pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
            <p className="text-gray-400 mb-4">Photo not found</p>
            <button onClick={() => router.back()} className="px-6 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-white">Go Back</button>
          </div>
        </main>
      </div>
    );
  }

  const anomalyData = photo?.anomalyData as any;
  const compareImageUrl = activeView === "compare" 
    ? (photo?.upscaledUrl ?? photo?.anomalyUrl ?? null) 
    : null;

  return (
    <div className="min-h-screen bg-[#0a0a1a] grid-bg">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="max-w-[1200px] mx-auto px-4">
          {/* Header */}
          <motion.div initial="hidden" animate="visible" variants={fadeUp} className="mb-8">
            <button onClick={() => router.back()} className="flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors mb-4">
              <ArrowLeft className="w-5 h-5" /> Back
            </button>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="font-orbitron text-2xl font-bold text-white mb-1">{photo?.fileName ?? "Photo Analysis"}</h1>
                <div className="flex items-center gap-4 text-gray-400 text-sm">
                  <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{photo?.createdAt ? new Date(photo.createdAt).toLocaleString() : ""}</span>
                  {photo?.fileSize && <span className="flex items-center gap-1"><HardDrive className="w-4 h-4" />{((photo.fileSize ?? 0) / 1024 / 1024).toFixed(2)} MB</span>}
                  {photo?.mimeType && <span className="flex items-center gap-1"><FileType className="w-4 h-4" />{photo.mimeType}</span>}
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleDownload(photo?.originalUrl, `original_${photo?.fileName ?? "photo"}`)} 
                  className="flex items-center gap-2 px-4 py-2 rounded-lg border border-cyan-500/30 text-cyan-400 text-sm hover:bg-cyan-500/10 transition-all">
                  <Download className="w-4 h-4" /> Original
                </button>
                {photo?.upscaledUrl && (
                  <button onClick={() => handleDownload(photo?.upscaledUrl, `upscaled_${photo?.fileName ?? "photo"}`)} 
                    className="flex items-center gap-2 px-4 py-2 rounded-lg border border-green-500/30 text-green-400 text-sm hover:bg-green-500/10 transition-all">
                    <Download className="w-4 h-4" /> Upscaled
                  </button>
                )}
              </div>
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Image viewer - 2 cols */}
            <motion.div initial="hidden" animate="visible" variants={fadeUp} className="lg:col-span-2">
              {/* View tabs */}
              <div className="flex gap-2 mb-4 flex-wrap">
                {[
                  { key: "original", label: "Original", icon: ImageIcon },
                  { key: "anomaly", label: "Anomaly Map", icon: Scan, disabled: photo?.anomalyStatus !== "COMPLETED" },
                  { key: "upscaled", label: "Upscaled", icon: ZoomIn, disabled: photo?.upscaleStatus !== "COMPLETED" },
                  { key: "compare", label: "Compare", icon: SplitSquareHorizontal, disabled: !photo?.upscaledUrl && !photo?.anomalyUrl },
                ].map((tab: any) => (
                  <button key={tab?.key}
                    onClick={() => !tab?.disabled && setActiveView(tab?.key)}
                    disabled={tab?.disabled}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-all ${
                      activeView === tab?.key
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : tab?.disabled
                          ? "text-gray-600 cursor-not-allowed"
                          : "text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"
                    }`}>
                    {tab?.icon && <tab.icon className="w-4 h-4" />}
                    {tab?.label}
                  </button>
                ))}
              </div>

              {/* Image display */}
              <div className="rounded-xl bg-[#0f0f2a]/80 border border-cyan-500/10 overflow-hidden">
                {activeView === "compare" && compareImageUrl ? (
                  <div ref={compareRef} onMouseMove={handleCompareMove} className="relative aspect-video cursor-col-resize select-none">
                    {/* Original (full) */}
                    <div className="absolute inset-0">
                      {photo?.originalUrl ? (
                        <img src={photo.originalUrl} alt="Original" className="w-full h-full object-contain" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-[#0a0a1a]"><ImageIcon className="w-16 h-16 text-gray-600" /></div>
                      )}
                    </div>
                    {/* Processed (clipped) */}
                    <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - comparePosition}% 0 0)` }}>
                      <img src={compareImageUrl} alt="Processed" className="w-full h-full object-contain" />
                    </div>
                    {/* Slider line */}
                    <div className="absolute top-0 bottom-0 w-0.5 bg-cyan-400 z-10" style={{ left: `${comparePosition}%` }}>
                      <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-cyan-400 flex items-center justify-center">
                        <SplitSquareHorizontal className="w-4 h-4 text-[#0a0a1a]" />
                      </div>
                    </div>
                    <div className="absolute top-3 left-3 px-2 py-1 rounded bg-black/60 text-white text-xs">Original</div>
                    <div className="absolute top-3 right-3 px-2 py-1 rounded bg-black/60 text-cyan-400 text-xs">Processed</div>
                  </div>
                ) : (
                  <div className="relative aspect-video">
                    <div className="w-full h-full overflow-auto flex items-center justify-center bg-[#0a0a1a]">
                      {activeView === "original" && photo?.originalUrl && (
                        <img src={photo.originalUrl} alt="Original" style={{ transform: `scale(${zoom})` }} className="max-w-full max-h-full object-contain transition-transform" />
                      )}
                      {activeView === "anomaly" && (
                        photo?.anomalyUrl ? (
                          <img src={photo.anomalyUrl} alt="Anomaly" style={{ transform: `scale(${zoom})` }} className="max-w-full max-h-full object-contain transition-transform" />
                        ) : photo?.originalUrl ? (
                          <div className="relative">
                            <img src={photo.originalUrl} alt="Anomaly overlay" style={{ transform: `scale(${zoom})` }} className="max-w-full max-h-full object-contain transition-transform" />
                            {photo?.anomalyStatus === "COMPLETED" && (
                              <div className="absolute inset-0 flex items-center justify-center">
                                <div className="px-4 py-2 rounded-lg bg-green-500/20 border border-green-500/30 text-green-400 text-sm">
                                  <CheckCircle2 className="w-5 h-5 inline mr-2" />Analysis complete - see results
                                </div>
                              </div>
                            )}
                          </div>
                        ) : (
                          <ImageIcon className="w-16 h-16 text-gray-600" />
                        )
                      )}
                      {activeView === "upscaled" && (
                        photo?.upscaledUrl ? (
                          <img src={photo.upscaledUrl} alt="Upscaled" style={{ transform: `scale(${zoom})` }} className="max-w-full max-h-full object-contain transition-transform" />
                        ) : (
                          <ImageIcon className="w-16 h-16 text-gray-600" />
                        )
                      )}
                      {activeView === "original" && !photo?.originalUrl && <ImageIcon className="w-16 h-16 text-gray-600" />}
                    </div>
                    {/* Zoom controls */}
                    <div className="absolute bottom-3 right-3 flex items-center gap-2 bg-black/60 rounded-lg p-1">
                      <button onClick={() => setZoom(Math.max(0.5, zoom - 0.25))} className="p-1 text-white hover:text-cyan-400"><MinusCircle className="w-5 h-5" /></button>
                      <span className="text-white text-xs min-w-[40px] text-center">{Math.round(zoom * 100)}%</span>
                      <button onClick={() => setZoom(Math.min(3, zoom + 0.25))} className="p-1 text-white hover:text-cyan-400"><PlusCircle className="w-5 h-5" /></button>
                      <button onClick={() => setZoom(1)} className="p-1 text-white hover:text-cyan-400"><Maximize2 className="w-4 h-4" /></button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>

            {/* Sidebar - 1 col */}
            <motion.div initial="hidden" animate="visible" variants={fadeUp} transition={{ delay: 0.1 }} className="space-y-4">
              {/* Actions */}
              <div className="p-5 rounded-xl bg-[#0f0f2a]/80 border border-cyan-500/10">
                <h3 className="font-orbitron text-sm font-bold text-white mb-4">Processing Actions</h3>
                <div className="space-y-3">
                  <button onClick={handleDetectAnomalies}
                    disabled={anomalyProcessing || photo?.anomalyStatus === "PROCESSING"}
                    className="w-full flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-purple-500/10 to-pink-600/10 border border-purple-500/20 hover:border-purple-500/40 text-white text-sm transition-all disabled:opacity-50">
                    {anomalyProcessing || photo?.anomalyStatus === "PROCESSING" ? (
                      <Loader2 className="w-5 h-5 text-purple-400 animate-spin" />
                    ) : photo?.anomalyStatus === "COMPLETED" ? (
                      <CheckCircle2 className="w-5 h-5 text-green-400" />
                    ) : (
                      <Scan className="w-5 h-5 text-purple-400" />
                    )}
                    <div className="text-left flex-1">
                      <p className="font-medium">{photo?.anomalyStatus === "COMPLETED" ? "Re-detect Anomalies" : "Detect Anomalies"}</p>
                      <p className="text-gray-400 text-xs">{anomalyProcessing ? "Processing..." : "AI-powered manipulation detection"}</p>
                    </div>
                  </button>

                  <button onClick={handleUpscale}
                    disabled={upscaleProcessing || photo?.upscaleStatus === "PROCESSING"}
                    className="w-full flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-cyan-500/10 to-blue-600/10 border border-cyan-500/20 hover:border-cyan-500/40 text-white text-sm transition-all disabled:opacity-50">
                    {upscaleProcessing || photo?.upscaleStatus === "PROCESSING" ? (
                      <Loader2 className="w-5 h-5 text-cyan-400 animate-spin" />
                    ) : photo?.upscaleStatus === "COMPLETED" ? (
                      <CheckCircle2 className="w-5 h-5 text-green-400" />
                    ) : (
                      <ZoomIn className="w-5 h-5 text-cyan-400" />
                    )}
                    <div className="text-left flex-1">
                      <p className="font-medium">{photo?.upscaleStatus === "COMPLETED" ? "Re-upscale Image" : "Upscale / Recreate"}</p>
                      <p className="text-gray-400 text-xs">{upscaleProcessing ? "Processing..." : "Neural network enhancement"}</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Anomaly results */}
              {photo?.anomalyStatus === "COMPLETED" && anomalyData && (
                <div className="p-5 rounded-xl bg-[#0f0f2a]/80 border border-cyan-500/10">
                  <h3 className="font-orbitron text-sm font-bold text-white mb-4 flex items-center gap-2">
                    <Eye className="w-4 h-4 text-cyan-400" /> Forensic Analysis Results
                  </h3>

                  {/* AI Generated / Manipulated badges */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {anomalyData?.is_ai_generated != null && (
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${anomalyData.is_ai_generated ? "bg-red-500/20 text-red-400 border border-red-500/30" : "bg-green-500/20 text-green-400 border border-green-500/30"}`}>
                        {anomalyData.is_ai_generated ? "⚠ AI Generated" : "✓ Not AI Generated"}
                      </span>
                    )}
                    {anomalyData?.is_manipulated != null && (
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${anomalyData.is_manipulated ? "bg-orange-500/20 text-orange-400 border border-orange-500/30" : "bg-green-500/20 text-green-400 border border-green-500/30"}`}>
                        {anomalyData.is_manipulated ? "⚠ Manipulated" : "✓ No Manipulation"}
                      </span>
                    )}
                  </div>

                  {anomalyData?.overall_score != null && (
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-400 text-sm">Authenticity Score</span>
                        <span className={`font-orbitron font-bold ${(anomalyData.overall_score ?? 0) >= 0.7 ? "text-green-400" : (anomalyData.overall_score ?? 0) >= 0.4 ? "text-yellow-400" : "text-red-400"}`}>
                          {Math.round((anomalyData.overall_score ?? 0) * 100)}%
                        </span>
                      </div>
                      <div className="h-2 rounded-full bg-[#0a0a1a] overflow-hidden">
                        <div className={`h-full rounded-full ${(anomalyData.overall_score ?? 0) >= 0.7 ? "bg-gradient-to-r from-cyan-500 to-green-500" : (anomalyData.overall_score ?? 0) >= 0.4 ? "bg-gradient-to-r from-yellow-500 to-orange-500" : "bg-gradient-to-r from-red-500 to-pink-500"}`}
                          style={{ width: `${(anomalyData.overall_score ?? 0) * 100}%` }} />
                      </div>
                      {anomalyData?.verdict && (
                        <p className={`text-sm mt-2 font-medium ${(anomalyData.overall_score ?? 0) >= 0.7 ? "text-green-400" : (anomalyData.overall_score ?? 0) >= 0.4 ? "text-yellow-400" : "text-red-400"}`}>
                          {anomalyData.verdict}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Summary */}
                  {anomalyData?.summary && (
                    <div className="mb-4 p-3 rounded-lg bg-[#0a0a1a] border border-cyan-500/10">
                      <p className="text-gray-300 text-xs leading-relaxed">{anomalyData.summary}</p>
                    </div>
                  )}

                  {(anomalyData?.findings ?? [])?.length > 0 && (
                    <div className="space-y-3">
                      <p className="text-gray-500 text-xs uppercase tracking-wider">Detailed Findings</p>
                      {(anomalyData.findings ?? []).map?.((f: any, i: number) => {
                        const severityColor = f?.severity === "critical" ? "border-red-500/30 bg-red-500/5" : f?.severity === "high" ? "border-orange-500/30 bg-orange-500/5" : f?.severity === "medium" ? "border-yellow-500/30 bg-yellow-500/5" : "border-cyan-500/5 bg-[#0a0a1a]";
                        const severityBadge = f?.severity === "critical" ? "bg-red-500/20 text-red-400" : f?.severity === "high" ? "bg-orange-500/20 text-orange-400" : f?.severity === "medium" ? "bg-yellow-500/20 text-yellow-400" : f?.severity === "low" ? "bg-blue-500/20 text-blue-400" : "bg-green-500/20 text-green-400";
                        return (
                          <div key={i} className={`p-3 rounded-lg border ${severityColor}`}>
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-white text-xs font-medium">{f?.type?.replace?.(/_/g, " ")?.toUpperCase?.() ?? ""}</span>
                              <div className="flex items-center gap-2">
                                {f?.severity && f.severity !== "none" && (
                                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${severityBadge}`}>{f.severity}</span>
                                )}
                                <span className="text-cyan-400 text-xs font-orbitron">{Math.round((f?.confidence ?? 0) * 100)}%</span>
                              </div>
                            </div>
                            <p className="text-gray-400 text-xs">{f?.description ?? ""}</p>
                            {f?.anomaly_detected && (
                              <p className="text-red-400 text-[10px] mt-1 font-medium">⚠ Anomaly Detected</p>
                            )}
                          </div>
                        );
                      }) ?? []}
                    </div>
                  )}
                </div>
              )}

              {/* Upscale info */}
              {photo?.upscaleStatus === "COMPLETED" && photo?.upscaleData && (
                <div className="p-5 rounded-xl bg-[#0f0f2a]/80 border border-cyan-500/10">
                  <h3 className="font-orbitron text-sm font-bold text-white mb-3 flex items-center gap-2">
                    <ZoomIn className="w-4 h-4 text-green-400" /> Upscale Details
                  </h3>
                  <div className="space-y-2 text-sm">
                    {(photo.upscaleData as any)?.scale_factor && (
                      <div className="flex justify-between"><span className="text-gray-400">Scale Factor</span><span className="text-white">{(photo.upscaleData as any).scale_factor}x</span></div>
                    )}
                    {(photo.upscaleData as any)?.method && (
                      <div className="flex justify-between"><span className="text-gray-400">Method</span><span className="text-white capitalize">{(photo.upscaleData as any).method?.replace?.(/_/g, " ") ?? ""}</span></div>
                    )}
                    {(photo.upscaleData as any)?.quality && (
                      <div className="flex justify-between"><span className="text-gray-400">Quality</span><span className="text-green-400 capitalize">{(photo.upscaleData as any).quality}</span></div>
                    )}
                  </div>
                </div>
              )}

              {/* Processing status indicators */}
              <div className="p-5 rounded-xl bg-[#0f0f2a]/80 border border-cyan-500/10">
                <h3 className="font-orbitron text-sm font-bold text-white mb-3">Status</h3>
                <div className="space-y-2">
                  {[
                    { label: "Anomaly Detection", status: photo?.anomalyStatus ?? "PENDING" },
                    { label: "Upscaling", status: photo?.upscaleStatus ?? "PENDING" },
                  ].map((item: any) => {
                    const color = item?.status === "COMPLETED" ? "text-green-400" : item?.status === "PROCESSING" ? "text-yellow-400" : item?.status === "FAILED" ? "text-red-400" : "text-gray-500";
                    const icon = item?.status === "COMPLETED" ? CheckCircle2 : item?.status === "PROCESSING" ? RefreshCw : item?.status === "FAILED" ? AlertCircle : Clock;
                    const IconComp = icon;
                    return (
                      <div key={item?.label} className="flex items-center justify-between">
                        <span className="text-gray-400 text-sm">{item?.label}</span>
                        <span className={`flex items-center gap-1 text-sm ${color}`}>
                          <IconComp className={`w-4 h-4 ${item?.status === "PROCESSING" ? "animate-spin" : ""}`} />
                          {item?.status ?? "PENDING"}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
