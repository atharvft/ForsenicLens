export const dynamic = "force-dynamic";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { getFileUrl, generatePresignedUploadUrl } from "@/lib/s3";

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const userId = (session.user as any)?.id;

    const photo = await prisma.photo.findFirst({ where: { id: params?.id, userId } });
    if (!photo) return NextResponse.json({ error: "Photo not found" }, { status: 404 });
    if (!photo.originalCloudPath && !photo.originalUrl) {
      return NextResponse.json({ error: "No original image available" }, { status: 400 });
    }

    // Mark as processing
    await prisma.photo.update({
      where: { id: params.id },
      data: { upscaleStatus: "PROCESSING", status: "PROCESSING" },
    });

    // Get the image URL
    let imageUrl = photo.originalUrl;
    if (!imageUrl && photo.originalCloudPath) {
      imageUrl = await getFileUrl(photo.originalCloudPath, photo.isOriginalPublic);
    }

    // Fetch image and convert to base64
    let base64Image: string;
    let mimeType = photo.mimeType || "image/jpeg";
    try {
      const imgResp = await fetch(imageUrl!);
      if (!imgResp.ok) throw new Error(`Failed to fetch image: ${imgResp.status}`);
      const imgBuffer = Buffer.from(await imgResp.arrayBuffer());
      base64Image = `data:${mimeType};base64,${imgBuffer.toString("base64")}`;
    } catch (fetchErr: any) {
      console.error("Image fetch error:", fetchErr);
      await prisma.photo.update({
        where: { id: params.id },
        data: { upscaleStatus: "FAILED", status: "FAILED" },
      });
      return NextResponse.json({ error: "Failed to fetch image for upscaling" }, { status: 500 });
    }

    const apiKey = process.env.ABACUSAI_API_KEY;
    if (!apiKey) {
      await prisma.photo.update({
        where: { id: params.id },
        data: { upscaleStatus: "FAILED", status: "FAILED" },
      });
      return NextResponse.json({ error: "AI API key not configured" }, { status: 500 });
    }

    try {
      // First, analyze the image to get a detailed description
      const analyzeResponse = await fetch("https://apps.abacus.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-4.1",
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: "Describe this image in detailed terms for recreating it at higher quality. Include objects, composition, colors, lighting, and all visible elements. Be specific and forensically accurate.",
                },
                { type: "image_url", image_url: { url: base64Image } },
              ],
            },
          ],
          max_tokens: 1000,
          temperature: 0.2,
        }),
      });

      if (!analyzeResponse.ok) {
        console.error("Image description failed:", analyzeResponse.status);
        throw new Error("Failed to analyze image for upscaling");
      }

      const analyzeData = await analyzeResponse.json();
      const imageDescription = analyzeData?.choices?.[0]?.message?.content || "A detailed photograph requiring quality enhancement";

      // Now generate the upscaled image based on the description
      const llmResponse = await fetch("https://apps.abacus.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-5.1",
          messages: [
            {
              role: "user",
              content: `Generate a high-quality, upscaled version of: ${imageDescription}. Produce the absolute highest quality possible. Use professional photography standards. Enhance clarity, sharpness, and detail while maintaining 100% accuracy to the original composition, colors, and content. This is for forensic image analysis - accuracy is critical.`,
            },
          ],
          modalities: ["image"],
          image_config: {
            num_images: 1,
            quality: "high",
            resolution: "2K",
          },
        }),
      });

      if (!llmResponse.ok) {
        const errText = await llmResponse.text();
        console.error("LLM upscale API error:", llmResponse.status, errText);
        await prisma.photo.update({
          where: { id: params.id },
          data: { upscaleStatus: "FAILED", status: "FAILED" },
        });
        return NextResponse.json({ error: `AI upscaling failed: ${llmResponse.status}` }, { status: 500 });
      }

      const llmData = await llmResponse.json();

      // Extract generated image from response
      const images = llmData?.choices?.[0]?.message?.images;
      if (!images || images.length === 0) {
        console.error("No images in upscale response", JSON.stringify(llmData).substring(0, 500));
        await prisma.photo.update({
          where: { id: params.id },
          data: { upscaleStatus: "FAILED", status: "FAILED" },
        });
        return NextResponse.json({ error: "AI upscaling did not return an image" }, { status: 500 });
      }

      // The image is a data URL (data:image/png;base64,...)
      const generatedImageUrl = images[0]?.image_url?.url ?? images[0]?.url ?? images[0];
      if (!generatedImageUrl || typeof generatedImageUrl !== "string") {
        await prisma.photo.update({
          where: { id: params.id },
          data: { upscaleStatus: "FAILED", status: "FAILED" },
        });
        return NextResponse.json({ error: "Invalid image format from AI" }, { status: 500 });
      }

      // Upload the upscaled image to S3
      let upscaledUrl = generatedImageUrl;
      let upscaledCloudPath: string | null = null;

      try {
        // Extract base64 data from data URL
        const base64Match = generatedImageUrl.match(/^data:([^;]+);base64,(.+)$/);
        if (base64Match) {
          const imgMime = base64Match[1];
          const imgData = base64Match[2];
          const ext = imgMime.includes("png") ? "png" : "jpg";
          const upscaleFileName = `upscaled_${photo.fileName?.replace(/\.[^.]+$/, "") ?? "photo"}.${ext}`;

          // Generate presigned URL and upload
          const { uploadUrl, cloud_storage_path } = await generatePresignedUploadUrl(
            upscaleFileName,
            imgMime,
            true
          );

          const imgBuffer = Buffer.from(imgData, "base64");

          // Check if content-disposition is in signed headers
          const signedHeadersMatch = uploadUrl.match(/X-Amz-SignedHeaders=([^&]+)/);
          const signedHeaders = signedHeadersMatch ? decodeURIComponent(signedHeadersMatch[1]) : "";
          const needsContentDisposition = signedHeaders.includes("content-disposition");

          const uploadHeaders: Record<string, string> = {
            "Content-Type": imgMime,
          };
          if (needsContentDisposition) {
            uploadHeaders["Content-Disposition"] = "attachment";
          }

          const uploadResp = await fetch(uploadUrl, {
            method: "PUT",
            headers: uploadHeaders,
            body: imgBuffer,
          });

          if (uploadResp.ok) {
            upscaledCloudPath = cloud_storage_path;
            upscaledUrl = await getFileUrl(cloud_storage_path, true);
          } else {
            console.error("S3 upload failed:", uploadResp.status, await uploadResp.text());
            // Fall back to data URL
          }
        }
      } catch (s3Err: any) {
        console.error("S3 upload error for upscaled image:", s3Err);
        // Fall back to data URL - it still works for display
      }

      // Update photo with upscaled result
      const updatedPhoto = await prisma.photo.update({
        where: { id: params.id },
        data: {
          upscaleStatus: "COMPLETED",
          upscaledUrl: upscaledUrl,
          upscaledCloudPath: upscaledCloudPath,
          isUpscaledPublic: true,
          upscaleData: {
            scale_factor: 2,
            method: "ai_image_generation",
            quality: "high",
            resolution: "2K",
            model: "gpt-5.1",
            enhanced: true,
            description_model: "gpt-4.1",
          },
          status: photo.anomalyStatus === "PROCESSING" ? "PROCESSING" : "COMPLETED",
        },
      });

      return NextResponse.json({
        success: true,
        photo: updatedPhoto,
      });
    } catch (llmErr: any) {
      console.error("LLM upscale call error:", llmErr);
      await prisma.photo.update({
        where: { id: params.id },
        data: { upscaleStatus: "FAILED", status: "FAILED" },
      });
      return NextResponse.json({ error: "AI upscaling failed: " + (llmErr?.message ?? "Unknown error") }, { status: 500 });
    }
  } catch (err: any) {
    console.error("Upscale route error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
